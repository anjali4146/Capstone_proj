package Assignment;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

public class Scrolling 
{
public static void main(String[] args) throws InterruptedException 
{
 WebDriver driver = new FirefoxDriver();
 driver.get("https://webdriveruniversity.com/Scrolling/index.html");
 driver.findElement(By.xpath("//div[@id='zone1']")).click();
 Thread.sleep(2000);
 driver.findElement(By.xpath("//h1[@id='zone2-entries']")).click();
 Thread.sleep(2000);
 driver.findElement(By.xpath("//h1[@id='zone3-entries']")).click();
 Thread.sleep(2000);
 
 JavascriptExecutor jse = (JavascriptExecutor)driver;
jse.executeScript("window.scrollBy(0,500)");
driver.findElement(By.xpath("//div[@id=\"zone4\"]")).click();


System.out.println("done");
driver.quit();


 
 
 
 
 
 
}
}
