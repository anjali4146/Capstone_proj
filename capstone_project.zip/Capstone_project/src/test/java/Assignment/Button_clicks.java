package Assignment;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;


public class Button_clicks 
{
 public static void main(String[] args) 
 {
 WebDriver driver = new FirefoxDriver();
 driver.get("https://webdriveruniversity.com/Click-Buttons/index.html");
 
 //1
 driver.findElement(By.xpath("//span[.='CLICK ME!']")).click();    
 driver.findElement(By.xpath("//div[@id='myModalClick' or class='btn btn-default']")).click();
 System.out.println("done 1");

 //2
 WebElement button = driver.findElement(By.cssSelector("span[id=\"button2\"]"));
 JavascriptExecutor jse = (JavascriptExecutor) driver;
 jse.executeScript("arguments[0].click();", button);
driver.findElement(By.xpath("//div[@class='modal-dialog modal-md' or class='close']")).click();
 System.out.println(" done 2");
 
// 3
WebElement ele1 = driver.findElement(By.xpath("//span[.='CLICK ME!!!']"));
Actions a = new Actions(driver);
a.click(ele1).perform();
WebElement ele2 = driver.findElement(By.xpath("//b[.='Action Move & Click' or class='btn btn-defaul']"));
a.click(ele2).perform();
 System.out.println("done 3");
 driver.close();
 
}

}
