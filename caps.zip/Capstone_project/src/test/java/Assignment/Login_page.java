package Assignment;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;


public class Login_page
{
	public static void main(String[] args)
	{
	  WebDriver driver = new FirefoxDriver(); 
		driver.manage().window().maximize();
		driver.get("https://webdriveruniversity.com/Login-Portal/index.html");
		driver.findElement(By.xpath("//input[@placeholder=\"Username\"]")).sendKeys("Anjali");
		driver.findElement(By.xpath("//input[@placeholder=\"Password\"]")).sendKeys("Anjali@1234");
		driver.findElement(By.xpath("//button[@id=\"login-button\"]")).click();		
		driver.switchTo().alert().accept();
	    System.out.println("DONE");
	    driver.close();
	}
    
}
