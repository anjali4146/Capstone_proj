package Assignment;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;


public class Button_clicks 
{
 @SuppressWarnings("deprecation")
public static void main(String[] args) 
 {
 WebDriver driver = new FirefoxDriver();
 driver.get("https://webdriveruniversity.com/Click-Buttons/index.html");
 
 //1
 driver.findElement(By.xpath("//span[.='CLICK ME!']")).click();    
 driver.findElement(By.xpath("//div[@id='myModalClick' or class='btn btn-default']")).click();
 System.out.println("done 1");

 //2
 WebElement button = driver.findElement(By.cssSelector("span[id=\"button2\"]"));
 JavascriptExecutor jse = (JavascriptExecutor) driver;
 jse.executeScript("arguments[0].click();", button);
 driver.manage().timeouts().implicitlyWait(500, java.util.concurrent.TimeUnit.SECONDS);
driver.findElement(By.xpath("//div[@class='modal-dialog modal-md' or class='close']")).click();
 System.out.println(" done 2");
 
// 3
WebElement ele1 = driver.findElement(By.xpath("//span[.='CLICK ME!!!']"));
Actions a = new Actions(driver);
a.click(ele1).perform();
driver.manage().timeouts().implicitlyWait(100, java.util.concurrent.TimeUnit.SECONDS);
driver.findElement(By.xpath("//b[.='Action Move & Click']"));
driver.manage().timeouts().implicitlyWait(50, java.util.concurrent.TimeUnit.SECONDS);
WebElement closeButton = driver.findElement(By.xpath("//div[@id=\"myModalMoveClick\" or Close]"));
a.moveToElement(closeButton).click().perform();
 System.out.println("done 3");
 driver.close();
 
}

}
