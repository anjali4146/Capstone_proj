package Assignment;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;

public class Action 
{

public static void main(String[] args) throws InterruptedException 
{
 WebDriver driver = new FirefoxDriver();
 driver.get("https://webdriveruniversity.com/Actions/index.html");
 
 //1
 WebElement ele1 =driver.findElement(By.xpath("//b[.='DRAG ME TO MY TARGET!']"));
 WebElement ele2 = driver.findElement(By.xpath("//p[.='DROP HERE!']"));
 Actions A = new Actions(driver);
 A.dragAndDrop(ele1, ele2).perform();
 System.out.println("drag and drop");
 
 //2
 WebElement ele3 = driver.findElement(By.xpath("//h2[.='Double Click Me!']"));
 A.doubleClick(ele3).perform();
 System.out.println("double button");
 
 //3
 WebElement ele4 = driver.findElement(By.xpath("//button[.='Hover Over Me First!']"));
 A.moveToElement(ele4).perform();
 
 //4
 WebElement ele5 = driver.findElement(By.xpath("//button[.='Hover Over Me Second!']"));
 A.moveToElement(ele5).perform();
 
 //5
 WebElement ele6 = driver.findElement(By.xpath("//button[.='Hover Over Me Third!']"));
 A.moveToElement(ele6).perform();
 
 //6
WebElement ele7 = driver.findElement(By.xpath("//p[.='Click and Hold!']"));
 A.clickAndHold(ele7);
 Thread.sleep(3000);
 
 driver.close();
 
 
 
}
}
