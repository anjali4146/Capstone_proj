package Assignment;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class Radio_button 
{
  public static void main(String[] args) 
  {
	WebDriver driver = new FirefoxDriver();
	driver.get("https://webdriveruniversity.com/Dropdown-Checkboxes-RadioButtons/index.html");
	driver.manage().window().maximize();
	
	//1A
	driver.findElement(By.xpath("//select[@id=\"dropdowm-menu-1\"]")).click();
	driver.findElement(By.xpath("//option[@value=\"java\"]")).click();
	System.out.println("A");
	
	//1B
	driver.findElement(By.xpath("//select[@id=\"dropdowm-menu-2\"]")).click();
	driver.findElement(By.xpath("//option[@value=\"testng\"]")).click();
	System.out.println("ABC");
	
	//1C
	driver.findElement(By.xpath("//select[@id=\"dropdowm-menu-3\"]")).click();
	driver.findElement(By.xpath("//option[@value=\"javascript\"]")).click();
	System.out.println("XYZ");
	
	//2
	driver.findElement(By.xpath("//input[@value=\"option-2\"]")).click();
	driver.findElement(By.xpath("//input[@value=\"option-1\"]")).click();
	driver.findElement(By.xpath("//input[@value=\"option-4\"]")).click();
	System.out.println("PQR");
	
	//3
	driver.findElement(By.xpath("//input[@value=\"blue\"]")).click();
	System.out.println("QRS");
	
	//4
	driver.findElement(By.xpath("//input[@value=\"lettuce\"]")).click();
	driver.findElement(By.xpath("//select[@id=\"fruit-selects\"]")).click();
	driver.findElement(By.xpath("//option[@value=\"pear\"]")).click();
	System.out.println("YZ");
	
	
	driver.close();
	
	
	
	
}
   
	
	
	
	
	
	
}
